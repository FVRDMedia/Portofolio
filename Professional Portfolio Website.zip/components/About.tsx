import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';

export function About() {
  const interests = [
    'Web Development',
    'UI/UX Design',
    'Photography',
    'Travel',
    'Coffee',
    'Open Source'
  ];

  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="mb-4">About Me</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get to know more about who I am, what I do, and what I'm passionate about.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <Card>
              <CardContent className="p-8">
                <div className="w-32 h-32 bg-gradient-to-br from-primary to-primary/70 rounded-full mx-auto mb-6"></div>
                <div className="text-center">
                  <h3 className="mb-2">Alex Johnson</h3>
                  <p className="text-muted-foreground mb-4">Full Stack Developer</p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {interests.map((interest) => (
                      <Badge key={interest} variant="secondary">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="mb-4">My Story</h3>
              <p className="text-muted-foreground mb-4">
                I'm a passionate full-stack developer with over 5 years of experience creating 
                digital solutions that bridge the gap between design and technology. My journey 
                began with a curiosity about how things work, which led me to pursue computer 
                science and develop a love for both coding and design.
              </p>
              <p className="text-muted-foreground mb-4">
                I specialize in building scalable web applications using modern technologies 
                like React, Node.js, and TypeScript. I believe in writing clean, maintainable 
                code and creating intuitive user experiences that make technology accessible 
                to everyone.
              </p>
              <p className="text-muted-foreground">
                When I'm not coding, you can find me exploring new coffee shops, capturing 
                moments through photography, or contributing to open-source projects that 
                make a difference in the developer community.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="mb-2">Location</h4>
                <p className="text-muted-foreground">San Francisco, CA</p>
              </div>
              <div>
                <h4 className="mb-2">Experience</h4>
                <p className="text-muted-foreground">5+ Years</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}