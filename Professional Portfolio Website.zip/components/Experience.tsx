import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';

export function Experience() {
  const experiences = [
    {
      title: 'Senior Full Stack Developer',
      company: 'TechCorp Inc.',
      period: '2022 - Present',
      description: 'Lead development of customer-facing web applications serving 100k+ users. Architected and implemented microservices infrastructure, reducing load times by 40%.',
      technologies: ['React', 'Node.js', 'TypeScript', 'AWS', 'PostgreSQL']
    },
    {
      title: 'Frontend Developer',
      company: 'StartupXYZ',
      period: '2020 - 2022',
      description: 'Developed responsive web applications and collaborated with design team to implement pixel-perfect UI components. Improved application performance by 60%.',
      technologies: ['Vue.js', 'JavaScript', 'SCSS', 'Webpack', 'Firebase']
    },
    {
      title: 'Junior Web Developer',
      company: 'Digital Agency Co.',
      period: '2019 - 2020',
      description: 'Built custom websites for clients across various industries. Learned modern web development practices and collaborated with cross-functional teams.',
      technologies: ['HTML', 'CSS', 'JavaScript', 'WordPress', 'PHP']
    },
    {
      title: 'Frontend Intern',
      company: 'Innovation Labs',
      period: '2018 - 2019',
      description: 'Assisted in developing user interfaces for internal tools and gained hands-on experience with modern frontend frameworks and version control.',
      technologies: ['React', 'Git', 'REST APIs', 'Bootstrap']
    }
  ];

  return (
    <section id="experience" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="mb-4">Work Experience</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            My professional journey and the roles that have shaped my expertise.
          </p>
        </div>

        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <div key={index} className="flex gap-8">
              <div className="flex flex-col items-center">
                <div className="w-4 h-4 bg-primary rounded-full"></div>
                {index < experiences.length - 1 && (
                  <div className="w-px h-32 bg-border mt-4"></div>
                )}
              </div>
              <Card className="flex-1">
                <CardHeader>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                    <CardTitle className="text-lg">{exp.title}</CardTitle>
                    <Badge variant="secondary">{exp.period}</Badge>
                  </div>
                  <CardDescription className="text-base font-medium">
                    {exp.company}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{exp.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {exp.technologies.map((tech) => (
                      <Badge key={tech} variant="outline" className="text-xs">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}