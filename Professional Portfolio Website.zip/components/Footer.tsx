import { Separator } from './ui/separator';

export function Footer() {
  return (
    <footer className="py-12 px-4 sm:px-6 lg:px-8 bg-muted/50">
      <div className="max-w-6xl mx-auto">
        <Separator className="mb-8" />
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="text-center sm:text-left">
            <p className="font-medium mb-1">Alex Johnson</p>
            <p className="text-sm text-muted-foreground">
              Full Stack Developer & UI/UX Designer
            </p>
          </div>
          <div className="text-center sm:text-right">
            <p className="text-sm text-muted-foreground">
              © 2024 Alex Johnson. All rights reserved.
            </p>
            <p className="text-sm text-muted-foreground">
              Built with React & Tailwind CSS
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}