import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Download, Mail, Github, Linkedin } from 'lucide-react';

export function Hero() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto text-center">
        <div className="mb-8">
          <Badge variant="secondary" className="mb-4">
            Available for opportunities
          </Badge>
          <h1 className="mb-6">
            Hi, I'm <span className="text-primary">Alex Johnson</span>
          </h1>
          <h2 className="text-muted-foreground mb-6">
            Full Stack Developer & UI/UX Designer
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            I create beautiful, functional, and user-centered digital experiences. 
            With expertise in modern web technologies and a passion for clean design, 
            I bring ideas to life through code.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
          <Button onClick={scrollToContact} className="w-full sm:w-auto">
            <Mail className="mr-2 h-4 w-4" />
            Get In Touch
          </Button>
          <Button variant="outline" className="w-full sm:w-auto">
            <Download className="mr-2 h-4 w-4" />
            Download Resume
          </Button>
        </div>

        <div className="flex justify-center space-x-4">
          <Button variant="ghost" size="sm">
            <Github className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="sm">
            <Linkedin className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
}